(defproject basic "1.0.0"
  :description "An example of using Midje's sweet interface"
  :dependencies [[org.clojure/clojure "[1.1.0,1.2.0]"]
                 [org.clojure/clojure-contrib "[1.1.0,1.2.0]"]
		 [midje "0.6.1"]]
)

