(defproject semi-sweet-simple "0.5.0"
  :description "An example of using Midje semi-sweet mocking"
  :dependencies [[org.clojure/clojure "[1.1.0,1.2.0]"]
                 [org.clojure/clojure-contrib "[1.1.0,1.2.0]"]
		 [midje "0.5.0"]
		 ]
)

