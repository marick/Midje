(ns semi-sweet-simple.core)
