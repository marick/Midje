(defproject basic "1.0.0"
  :description "An example of using Midje's sweet interface"
  :dependencies [[org.clojure/clojure "[1.2.0,1.2.1]"]
                 [org.clojure/clojure-contrib "[1.2.0,1.2.1]"]
		 ]
  :dev-dependencies [[midje "1.3.1-SNAPSHOT"]
                     [lein-midje "[1.0.0,)"]])

